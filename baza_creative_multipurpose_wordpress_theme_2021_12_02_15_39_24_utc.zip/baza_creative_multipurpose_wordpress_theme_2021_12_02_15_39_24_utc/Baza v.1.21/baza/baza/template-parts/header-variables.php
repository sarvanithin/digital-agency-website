:root {
--primary-color: <?php echo esc_html(get_theme_mod('pr_color', '#155ce7')); ?>;
--primary-links-hover-color: <?php echo esc_html(get_theme_mod('pr_links_h_color', '#20292f')); ?>;
--primary-bg-color: <?php echo esc_html(get_theme_mod('pr_bg_color', '#f6f9fe')); ?>;
--header-bg-color: <?php echo esc_html(get_theme_mod('h_bg_color', '#f8f9fa')); ?>;
--footer-bg-color: <?php echo esc_html(get_theme_mod('f_bg_color', '#f8f9fa')); ?>;
--primary-dark-color: <?php echo esc_html(get_theme_mod('pr_d_color', '#20292f')); ?>;
--title-color: <?php echo esc_html(get_theme_mod('title_color', '#20292f')); ?>;
--fw-title-color: <?php echo esc_html(get_theme_mod('fw_title_color', '#0a2540')); ?>;
--btn-bg-color: <?php echo esc_html(get_theme_mod('btn_bg_color', '#155ce7')); ?>;
--btn-hover-color: <?php echo esc_html(get_theme_mod('btn_h_color', '#124ec1')); ?>;
--txt-select-bg-color: <?php echo esc_html(get_theme_mod('txt_select_bg_color', '#e0e7fa')); ?>;
}